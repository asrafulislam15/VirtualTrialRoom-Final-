import os.path

from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import render, redirect
from django.views import View
from django.views.decorators import gzip
from .forms import CustomerRegistrationForm, CustomerProfileForm
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from cvzone.PoseModule import PoseDetector
from .models import *
import cv2
import cvzone
import threading
from math import hypot


class ProductView(View):
    def get(self, request):
        totalitem = 0
        topwearsfemale = Product.objects.filter(category='Top Wear Female')
        topwearsmale = Product.objects.filter(category='Top Wear Male')

        print(topwearsfemale)

        if request.user.is_authenticated:
            totalitem = len(Cart.objects.filter(user=request.user))

        return render(request, 'app/home.html',
                      {'topwearsmale': topwearsmale, 'topwearsfemale': topwearsfemale, 'totalitem': totalitem})


class ProductDeatilView(View):
    def get(self, request, pk):
        totalitem = 0
        product = Product.objects.get(pk=pk)
        item_already_in_cart = False
        if request.user.is_authenticated:
            item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
            totalitem = len(Cart.objects.filter(user=request.user))
        return render(request, 'app/productdetail.html',
                      {'product': product, 'item_already_in_cart': item_already_in_cart, 'totalitem': totalitem})


@login_required
def add_to_cart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id)
    Cart(user=user, product=product).save()
    return redirect('/cart')


@login_required
def show_cart(request, totalitem=0):
    user = request.user
    cart = Cart.objects.filter(user=user)
    amount = 0.0
    shipping_amount = 60.0
    cart_product = [p for p in Cart.objects.all() if p.user == user]
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
            totalamount = amount + shipping_amount
        totalitem = len(Cart.objects.filter(user=request.user))
        return render(request, 'app/addtocart.html',
                      {'carts': cart, 'totalamount': totalamount, 'amount': amount, 'totalitem': totalitem})
    else:
        return render(request, 'app/emptycart.html', {'totalitem': totalitem})


def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity += 1
        c.save()
        amount = 0.0
        shipping_amount = 60.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount': amount + shipping_amount
        }
        return JsonResponse(data)


def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity -= 1
        c.save()
        amount = 0.0
        shipping_amount = 60.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount': amount + shipping_amount
        }
        return JsonResponse(data)


def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.delete()
        amount = 0.0
        shipping_amount = 60.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        data = {
            'amount': amount,
            'totalamount': amount + shipping_amount
        }
        return JsonResponse(data)


def buy_now(request):
    totalitem = 0
    if request.user.is_authenticated:
        totalitem = len(Cart.objects.filter(user=request.user))
    return render(request, 'app/buynow.html', {'totalitem': totalitem})


@login_required
def address(request):
    add = Customer.objects.filter(user=request.user)
    totalitem = len(Cart.objects.filter(user=request.user))
    return render(request, 'app/address.html', {'add': add, 'active': 'btn-primary', 'totalitem': totalitem})


@login_required
def orders(request):
    op = OrderPlaced.objects.filter(user=request.user)
    totalitem = len(Cart.objects.filter(user=request.user))
    return render(request, 'app/orders.html', {'order_placed': op, 'totalitem': totalitem})


def topwearmale(request, data=None):
    totalitem = 0
    topwearsmale = Product.objects.filter(category='Top Wear Male')

    price_range = {
        "min_price": None,
        "max_price": None
    }

    if request.GET.get('min_price'):
        topwearsmale = topwearsmale.filter(discounted_price__gt=request.GET.get('min_price'))
        price_range.update({'min_price': request.GET.get('min_price')})
    if request.GET.get('max_price'):
        topwearsmale = topwearsmale.filter(discounted_price__lt=request.GET.get('max_price'))
        price_range.update({'max_price': request.GET.get('max_price')})

    if request.user.is_authenticated:
        totalitem = len(Cart.objects.filter(user=request.user))

    return render(request, 'app/topwearmale.html',
                  {'topwearsmale': topwearsmale, 'totalitem': totalitem, 'price_range': price_range})


def topwearfemale(request, data=None):
    totalitem = 0
    topwearsfemale = Product.objects.filter(category='Top Wear Female')

    price_range = {
        "min_price": None,
        "max_price": None
    }

    if request.GET.get('min_price'):
        topwearsfemale = topwearsfemale.filter(discounted_price__gt=request.GET.get('min_price'))
        price_range.update({'min_price': request.GET.get('min_price')})
    if request.GET.get('max_price'):
        topwearsfemale = topwearsfemale.filter(discounted_price__lt=request.GET.get('max_price'))
        price_range.update({'max_price': request.GET.get('max_price')})

    if request.user.is_authenticated:
        totalitem = len(Cart.objects.filter(user=request.user))

    return render(request, 'app/topwearfemale.html',
                  {'topwearsfemale': topwearsfemale, 'totalitem': totalitem, 'price_range': price_range})


class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html', {'form': form})

    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations!! Registered Successfully')
            form.save()
        return render(request, 'app/customerregistration.html', {'form': form})


@login_required
def checkout(request):
    user = request.user
    add = Customer.objects.filter(user=user)
    cart_items = Cart.objects.filter(user=user)
    amount = 0.0
    shipping_amount = 60.0
    totalamount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user == request.user]
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        totalamount = amount + shipping_amount
    totalitem = len(Cart.objects.filter(user=request.user))
    return render(request, 'app/checkout.html',
                  {'add': add, 'totalamount': totalamount, 'cart_items': cart_items, 'totalitem': totalitem})


@login_required
def payment_done(request):
    user = request.user
    custid = request.GET.get('custid')
    customer = Customer.objects.get(id=custid)
    cart = Cart.objects.filter(user=user)
    for c in cart:
        OrderPlaced(user=user, customer=customer, product=c.product, quantity=c.quantity).save()
        c.delete()
    return redirect('orders')


@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
        form = CustomerProfileForm()
        totalitem = len(Cart.objects.filter(user=request.user))
        return render(request, 'app/profile.html', {'form': form, 'active': 'btn-primary', 'totalitem': totalitem})

    def post(self, request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user=usr, name=name, locality=locality, city=city, state=state, zipcode=zipcode)
            reg.save()
            messages.success(request, 'Congratulations!! Profile Updated Successfully')
            totalitem = len(Cart.objects.filter(user=request.user))
        return render(request, 'app/profile.html', {'form': form, 'active': 'btn-primary', 'totalitem': totalitem})


def search(request):
    q = request.GET.get('q')

    data = Product.objects.filter(title__icontains=q or '')
    price_range = {
        "min_price": None,
        "max_price": None
    }

    if request.GET.get('min_price'):
        data = data.filter(discounted_price__gt=request.GET.get('min_price'))
        price_range.update({'min_price': request.GET.get('min_price')})
    if request.GET.get('max_price'):
        data = data.filter(discounted_price__lt=request.GET.get('max_price'))
        price_range.update({'max_price': request.GET.get('max_price')})

    return render(request, 'app/search-product.html',
                  {'products': data.order_by('-id'), 'totalItemFound': data.count(), 'price_range': price_range})


@gzip.gzip_page
def trial_room_projection(request, product_id):
    try:
        product = Product.objects.filter(id=product_id).first()
        cam = captureVideoCamera()
        return StreamingHttpResponse(gen(cam, os.path.abspath(product.product_image.path)), content_type="multipart/x-mixed-replace;boundary=frame")
    except():
        pass

    return render(request, 'app/trial_room_projection.html')


class captureVideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        (self.grabbed, self.frame) = self.video.read()
        self.detector = PoseDetector()
        threading.Thread(target=self.update, args=()).start()

    def __del__(self):
        self.video.release()

    def get_frame(self, dress):
        global result
        frame = self.frame
        cam_data = self.detector.findPose(frame)
        camimlist, cambboxinfo = self.detector.findPosition(cam_data, bboxWithHands=True)

        prod_data = cv2.imread(dress, cv2.IMREAD_UNCHANGED)

        def add_percentage_value(value, percent):
            return int(value + (value * percent / 100))

        def deduct_percentage_value(value, percent):
            return int(value - (value * percent / 100))

        if len(camimlist) > 24:
            top_right = [camimlist[11][1], camimlist[11][2]]
            top_left = [camimlist[12][1], camimlist[12][2]]
            bottom_right = [camimlist[23][1], camimlist[23][2]]
            bottom_left = [camimlist[24][1], camimlist[24][2]]

            total_dimension = (top_right, top_left, bottom_right, bottom_left)

            body_width = int(hypot(
                top_right[0] - top_left[0],
                bottom_right[0] - top_left[0]
            ))

            body_height = int(hypot(
                bottom_right[1] - top_right[1],
                bottom_left[1] - top_left[1]
            ))

            prod_data = cv2.resize(prod_data, (add_percentage_value(body_width, 40), add_percentage_value(body_height, 5)))

            # width = top_right[0] - top_left[0]
            # height = bottom_left[1] - top_left[1]
            #
            # prod_height = prod_data.shape[0]
            # prod_width = prod_data.shape[1]

            for x in range(0, 4):
                result = cv2.circle(cam_data, (total_dimension[x][0], total_dimension[x][1]), 5, (0, 255, 0), -1)

            # prod_main_coor = np.float32([[0, 0], [prod_width, 0], [0, prod_height], [prod_width, prod_height]])
            #
            # prod_coor = np.float32([
            #     [deduct_percentage_value(top_left[0], 40), deduct_percentage_value(top_left[1], 15)],
            #     [add_percentage_value(top_right[0], 20), deduct_percentage_value(top_right[1], 15)],
            #     [deduct_percentage_value(bottom_left[0], 40), add_percentage_value(bottom_left[1], 10)],
            #     [add_percentage_value(bottom_right[0], 20), add_percentage_value(bottom_right[1], 10)]
            # ])

            # prod_matrix = cv2.getPerspectiveTransform(prod_main_coor, prod_coor)
            #
            # prod_data = cv2.warpPerspective(prod_data, prod_matrix, (cam_data.shape[1], cam_data.shape[0]))

            # result = cv2.putText(cam_data, f'{camimlist[12][0]}, {camimlist[12][1]}, {camimlist[12][2]}', (10, 410), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            # result = cv2.putText(cam_data, f'{camimlist[11][0]}, {camimlist[11][1]}, {camimlist[11][2]}', (10, 460), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            if camimlist[12][1] and camimlist[11][1]:
                try:
                    width = deduct_percentage_value(top_left[0], 22)
                    height = deduct_percentage_value(top_left[1], 27)
                    result = cvzone.overlayPNG(cam_data, prod_data, [width, height])
                except Exception:
                    result = cv2.putText(cam_data, f'Please Get Back To Fit The Dress To Camera.', (10, 460), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            else:
                result = cv2.putText(cam_data, f'Please Get Back To Fit The Dress To Camera.', (10, 460), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            _, jpg = cv2.imencode('.jpg', result)
        else:
            _, jpg = cv2.imencode('.jpg', cam_data)

        return jpg.tobytes()

    def update(self):
        while True:
            (self.grabbed, self.frame) = self.video.read()


def gen(camera, dress):
    while True:
        frame = camera.get_frame(dress)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')
